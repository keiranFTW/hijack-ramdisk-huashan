#!/sbin/sh
#
# @(#) postrecoveryboot.sh for Xperia ver. 1.3.0 2013.06.23
#
# Description:
#   A postrecoveryboot script that simple function with logging.
#
# Author:
#   cray_Doze
#
###########################################################################

# Constant definition
LOGPATH="/cache/chargemon"
LOGFILE="${LOGPATH}/postrecoveryboot.log"

# Environment variable definition
PATH="/sbin"; export PATH

# Function definition for logging
ECHOL(){
  _DATETIME=`date +"%Y%m%d %H%M%S"`
  echo "${_DATETIME}: $*" >> ${LOGFILE}
  return 0
}
EXECL(){
  _DATETIME=`date +"%Y%m%d %H%M%S"`
  echo "${_DATETIME}: $*" >> ${LOGFILE}
  $* 2>> ${LOGFILE}
  _RET=$?
  echo "${_DATETIME}: RET=${_RET}" >> ${LOGFILE}
  return ${_RET}
}

# Logfile rotation
if [ ! -d "${LOGPATH}" ];then
  mkdir ${LOGPATH}
  chown system.cache ${LOGPATH}
  chmod 770 ${LOGPATH}
else
  if [ -f ${LOGFILE} ];then
    mv ${LOGFILE} ${LOGFILE}.old
  fi
  touch ${LOGFILE}
  chmod 660 ${LOGFILE}
fi

# Start main routine
ECHOL "### postrecoveryboot start..."

# umount partitions.
ECHOL "### umount partitions..."
for MOUNTPOINT in $(cat /proc/mounts | grep "^/dev/block" | sort -r -k 2,2 | awk '{print $2}')
do
  ECHOL "### MOUNTPOINT=${MOUNTPOINT}"
  if [ "${MOUNTPOINT}" != "/cache" ]; then
    EXECL umount -l ${MOUNTPOINT}
  fi
done
 
# setup zoneinfo
EXECL tar xf /zoneinfo.tar

# setup recovery.fstab
ECHOL "### setup recovery.fstab..."
if [ -f /proc/mtd ]; then
  EXECL cp -p /etc/recovery_mogami.fstab /etc/recovery.fstab
elif [ "`cat /proc/partitions | grep mmcblk0p | tail -1 | awk '{print $4}'`" = "mmcblk0p15" ]; then
  if [ "$(parted -s /dev/block/mmcblk0 print | grep -e '^15 ' | awk '{print $5'})" = "ext4" ]; then
    EXECL cp -p /etc/recovery_blue.fstab /etc/recovery.fstab
  elif [ "$(cat /proc/partitions | grep mmcblk1p1)" = "" ]; then
    EXECL cp -p /etc/recovery_fuji-1.fstab /etc/recovery.fstab 
  else
    EXECL cp -p /etc/recovery_fuji-2.fstab /etc/recovery.fstab
  fi
else
  EXECL cp -p /etc/recovery_lagan.fstab /etc/recovery.fstab 
fi

EXECL /sbin/setprop ctl.stop console

# Kill remaining processes under /system/bin
ECHOL "### kill remaining processes under /sytem/bin..."
for RUNNINGPRC in $(ps | grep /system/bin | grep -v grep | awk '{print $1}' )
do
  EXECL kill -9 ${RUNNINGPRC}
done

ECHOL "### postrecoveryboot end..."
